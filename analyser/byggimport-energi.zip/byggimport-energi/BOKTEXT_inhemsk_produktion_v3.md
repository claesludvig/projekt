Mellan 15 och 20 procent av byggmaterialet i Sverige är importerat (Konkurrensverket 2021). Det ger en fingervisning om hur väl den svenska byggsektorn är skyddad mot omvärldshändelser som riskerar att störa kostnadsutvecklingen, även om utbudsstörningar går genom flera mekanismer och led i produktionen och därför snabbt kan få genomslag. Huvudparten av byggmaterialet är inhemskt producerat och beroende av svenska energipriser, men materialen skiljer sig i hur känsliga de är för energipriserna, beroende på hur energiintensiv tillverkningen är.

Stora delar av den inhemska försörjningen är koncentrerad till fysiskt tunga material, där transportkostnaderna skapar lokala marknader. Cement, ballast och betong är naturliga exempel. Cementen tillverkas nästan helt av Cementa, i dag Heidelberg Materials, och importen motsvarar ungefär en sjättedel av förbrukningen, främst från Lettland (Boverket 2022). Hur sårbar en sådan försörjning är visade cementkrisen 2021. Mark- och miljööverdomstolen avslog då ansökan om fortsatt kalkbrytning i Slite, och med fabriken på Gotland hotades huvuddelen av den svenska cementförsörjningen, med radikala konsekvenser för samhällsbyggandet. Riksdagen fick på kort tid ändra lagen för att brytningen skulle kunna fortsätta, och först hösten 2026 vann ett nytt långsiktigt tillstånd laga kraft.

Att importandelen för cement är låg innebär inte att priserna sätts utifrån den inhemska produktionskostnaden. De relaterar i stället till produktionskostnaderna i Europa, där kontinentens energipriser blir avgörande. Även om marknaderna är lokala förblir prisbildningen därmed knuten till den europeiska utvecklingen. Konkurrensverket har återkommande pekat på bristande konkurrens och transparens i byggmaterialindustrin. Marknaderna för bland annat cement, mineralull och gips är starkt koncentrerade (Konkurrensverket 2021), och så kallade retroaktiva rabatter, som inte syns för beställaren, försvårar prisbildningen (Konkurrensverket 2025). Det håller tillbaka en mer gynnsam kostnadsutveckling.

Trävaror fungerar på ett liknande sätt. Skogsindustrin ger en hög grad av inhemsk försörjning, men omkring tre fjärdedelar av de sågade trävarorna går på export (Skogsindustrierna 2025). Även om försörjningen är skyddad av den inhemska produktionen förblir prisbildningen därför internationell, och priset blir beroende av den utländska efterfrågan.

Referenser att lägga till:

Boverket (2022), *Efterfrågan på cement och möjliga klimateffekter av ökad import*, rapport 2022:11, Karlskrona.

Konkurrensverket (2021), *Konkurrensen i byggmaterialindustrin*, rapport 2021:4, Stockholm.

Konkurrensverket (2025), *Pristransparens på byggmaterial*, rapport 2025:6, Stockholm.

Skogsindustrierna (2025), *Koll på svensk skogsindustri 2025*, Stockholm.
